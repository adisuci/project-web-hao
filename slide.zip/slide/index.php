<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />    
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="icon" href="dk.png">
	<title>Dewan Bootstrap 4 Corousel</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>

	<div class="bd-example mt-5">
	  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
	    <ol class="carousel-indicators">
	      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
	      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
	      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
	    </ol>
	    <div class="carousel-inner">
		  <div class="carousel-item active">
	        <img src="slide3.jpg" class="d-block w-100" alt="gambar">
	        <div class="carousel-caption d-none d-md-block">
	          <h3></h3>
	          <p></p>
	        </div>
	      </div>
	      <div class="carousel-item">
	        <img src="slide4.jpg" class="d-block w-100" alt="gambar">
	        <div class="carousel-caption d-none d-md-block">
	          <h3></h3>
	          <p></p>
	        </div>
	      </div>
	      <div class="carousel-item">
	        <img src="slide1.png" class="d-block w-100" alt="gambar">
	        <div class="carousel-caption d-none d-md-block">
	          <h3></h3>
	          <p></p>
	        </div>
	      </div>
	      <div class="carousel-item">
	        <img src="slide2.png" class="d-block w-100" alt="gambar">
	        <div class="carousel-caption d-none d-md-block">
	          <h3></h3>
	          <p></p>
	        </div>
	      </div>
	    </div>
	    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
	      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
	      <span class="sr-only">Previous</span>
	    </a>
	    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
	      <span class="carousel-control-next-icon" aria-hidden="true"></span>
	      <span class="sr-only">Next</span>
	    </a>
	  </div>
	</div>

		

</body>
</html>